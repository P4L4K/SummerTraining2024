#include<iostream>

int var=50; //global variable

int v=0;